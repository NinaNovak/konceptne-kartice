from tkinter import *
okno = Tk()
okvir = Frame(okno, width=400, height=50)
okvir.pack()
vnos = Entry(okno)
vnos.pack
besedilo = StringVar()
besedilo.set('Napiši kaj in pritisni tipko Enter.')
def tipka_enter(event=None):
    print('Hello')
    a = vnos.get()
    besedilo.set(a)
okvir.bind("<Return>", tipka_enter())
izpis = Message(okno, textvariable=besedilo)
izpis.pack()
okno.mainloop( )
##def potrdi():
##    """Dejanje za gumb potrdi."""
##    novo_okno = Toplevel()  #hčerinsko okno
##    vnos1 = v1.get()  #pridobivanje uporabnikovega
##    vnos2 = v2.get()  #vnosa  
##    besedilo_sporocila = "Dragi " + vnos1 +\
##                         "!\nObilo veselja pri tvojem hobiju, ki je " +\
##                         vnos2 + "!"
##    sporocilo = Message(novo_okno, text=besedilo_sporocila, width=300)  #gradnik Message
##    sporocilo.pack()
##
##    zapri = Button(novo_okno, text="Zapri okno!", command=novo_okno.destroy)
##    zapri.pack()
##
##potrdi = Button(okno, text ="Tvoje personalizirano sporočilo",
##                      command = potrdi)
##potrdi.grid(row = 2, column = 0, columnspan = 2)
