from tkinter import *

okno = Tk()

napis = "Vpiši besedilo, ki naj se izpiše v konzoli:"
Label(okno, text=napis).grid(row=0)

v1 = Entry(okno)



v2.grid(row=1)

def potrdi():
    """Dejanje za gumb potrdi."""
    novo_okno = Toplevel()  #hčerinsko okno
    vnos1 = v1.get()  #pridobivanje uporabnikovega
    vnos2 = v2.get()  #vnosa  
    besedilo_sporocila = "Dragi " + vnos1 +\
                         "!\nObilo veselja pri tvojem hobiju, ki je " +\
                         vnos2 + "!"
    sporocilo = Message(novo_okno, text=besedilo_sporocila, width=300)  #gradnik Message
    sporocilo.pack()

    zapri = Button(novo_okno, text="Zapri okno!", command=novo_okno.destroy)
    zapri.pack()

potrdi = Button(okno, text ="Tvoje personalizirano sporočilo",
                      command = potrdi)
potrdi.grid(row = 2, column = 0, columnspan = 2)

mainloop( )
