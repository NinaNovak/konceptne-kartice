from turtle import *

mojca = Turtle()
mojca.pencolor('red')
for i in range(1, 7):
    zelva = mojca.clone()
    #vsak klon se obrne v desno
    #za (i * 60) stopinj
    zelva.right(i * 60)
    #
    zelva.right(40)
    k = 10
    while k > 0:
        zelva.forward(20)
        zelva.left(8)
        k -= 1
    zelva.forward(20)
    zelva.left(100)
    j = 10
    while j > 0:
        zelva.forward(20)
        zelva.left(8)
        j -= 1
    zelva.forward(20)
    
