from tkinter import *

okno = Tk()  #glavno okno

Label(okno, text="Ime: ").grid(row=0)
Label(okno, text="Napiši svoj najljubši hobi: ").grid(row=1)  #besedili pred vnosnima poljema

v1 = Entry(okno)  #vnosni polji
v2 = Entry(okno)

v1.grid(row=0, column=1)  #z grid umestimo gradnike
v2.grid(row=1, column=1)  #v okno

def potrdi():
    """Dejanje za gumb potrdi."""
    novo_okno = Toplevel()  #hčerinsko okno
    vnos1 = v1.get()  #pridobivanje uporabnikovega
    vnos2 = v2.get()  #vnosa  
    besedilo_sporocila = "Dragi " + vnos1 +\
                         "!\nObilo veselja pri tvojem hobiju, ki je " +\
                         vnos2 + "!"
    sporocilo = Message(novo_okno, text=besedilo_sporocila, width=300)  #gradnik Message
    sporocilo.pack()

    zapri = Button(novo_okno, text="Zapri okno!", command=novo_okno.destroy)
    zapri.pack()

potrdi = Button(okno, text ="Tvoje personalizirano sporočilo",
                      command = potrdi)
potrdi.grid(row = 2, column = 0, columnspan = 2)

mainloop( )
