def pozdravi(ime, spol):
    '''Izpiše pozdrav osebi.

    Pri besedi "Pozdravljen" upošteva spol
    osebe. Spol je lahko 'm' ali 'z'.
    
    Primera:
    "Pozdravljen, Jure!"
    "Pozdravljena, Ana!"
    
    '''
    #določitev končnice
    if spol == 'm':
        koncnica = ', '
    else:
        koncnica = 'a, '
    #izpišemo
    print('Pozdravljen' + koncnica + ime + '!')
