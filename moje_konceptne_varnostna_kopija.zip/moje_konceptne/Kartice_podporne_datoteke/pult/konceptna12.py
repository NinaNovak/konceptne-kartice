def rojstniDnevi(datoteka, danes):
    """Izpiše imena oseb, ki so se rodile na današnji dan,
	    ter pred koliko leti so se rodile."""
    datumi = open(datoteka, "r")
    vrstica = datumi.readline()
    letos = int(danes[-4:])  #letošnja letnica
    a = len(danes) - 4  #pri katerem znaku se pri danes začne letnica
    dan = danes[:a]  #današnji datum (brez letnice), ki ga iščemo v datoteki
    dolzina = len(dan)  #iz koliko znakov je datum, ki ga iščemo   
    while vrstica != "":
        if vrstica[0:dolzina] == dan:  #ali je datum rojstva današnji dan?
            neletos = int(vrstica[a:a + 4])  #leto, ko se je oseba rodila
            starost = letos - neletos  #izračunamo starost slavljenca
            #s konca vrstice odstranimo skok v novo vrsto
            vrstica = vrstica.strip()
            print(vrstica + " (pred " + str(starost) + " leti)")
        vrstica = datumi.readline()
    datumi.close()
