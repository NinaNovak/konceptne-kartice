import turtle
platno = turtle.Screen()  #ustvarimo zaslon

turtle.width(7)           #širina narisane črte
turtle.turtlesize(2)      #velikost želve
turtle.color("green")     #barva narisane črte
turtle.shape("turtle")    #oblika pisala

#funkcije za tipke
def naprej():             #PREMIK naprej
    turtle.fd(45)
def nazaj():              #PREMIK nazaj
    turtle.bk(45)
def levo():               #OBRAT levo
    turtle.lt(45)
def desno():              #OBRAT desno
    turtle.rt(45)
def odtis():              #pusti odtis
    turtle.stamp()    
def dvigni():             #dvigni pisalo
    turtle.up()    
def spusti():             #spusti pisalo
    turtle.down()

#povežemo tipke s funkcijami za tipke
platno.onkey(naprej, "Up")
platno.onkey(levo, "Left")
platno.onkey(desno, "Right")
platno.onkey(nazaj, "Down")
platno.onkey(odtis, "space")
platno.onkey(dvigni, "d")
platno.onkey(spusti, "s")

platno.listen()    #posluša za dogodki -uporabo tipk- na platnu
platno.mainloop()  #koda se izvaja, dokler ne zapremo okna s platnom
