from tkinter import *

okno = Tk()  #glavno okno
slika = PhotoImage(file="pomol.gif")

#V programu moramo imeti še eno referenco na sliko,
#v nasprotnem primeru jo Python izbriše iz lokalnega spomina.
oznaka = Label(image=slika)
oznaka.image = slika  #referenca!
oznaka.pack()
