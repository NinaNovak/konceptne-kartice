import tkinter
import random

okno = tkinter.Tk()
platno = tkinter.Canvas(okno, width=200,height=200)
platno.pack()

def barve():
    #izbira barve
    barve = ["red", "green", "yellow", "orange"]
    izbrana_barva = random.choice(barve)
    #risanje kroga
    platno.create_oval(50, 50, 150, 150,
                       outline=izbrana_barva,
                       fill=izbrana_barva)
    
gumb = tkinter.Button(okno, text ="Spremeni barvo!",
                      command = barve)
gumb.pack()
barve()
okno.mainloop()
