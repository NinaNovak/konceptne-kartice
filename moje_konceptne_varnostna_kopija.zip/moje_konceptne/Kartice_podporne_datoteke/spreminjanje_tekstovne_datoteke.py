#Datoteke ne moremo spreminjati na mestu
#zato ustvarimo novo prazno datoteko in
#jo napolnimo s prepisovanjem.

#odpremo podano datoteko
with open(pot,  'r') as dat:
    #odpremo novo datoteko
    with open(nova, 'w') as nova_dat:
        #prvo vrstico moramo prebrati izven zanke
        vrstica = dat.readline()
        #dokler ne pridemo do konca datoteke
        while vrstica != '':
            #vrstic == '\n' ne spreminjamo
            if vrstica != '\n':
                #to je zadnja vrstica v datoteki
                if vrstica[-1] != '\n':
                    vrstica = vrstica + '.'
                #v vse ostale vrstice vrinemo piko
                #pred znak za skok v novo vrsto '\n'
                vrstica = vrstica[:-1] + '.' + \
                          vrstica[-1]
            #(ne)spremenjeno vrstico
            #zapisemo v novo datoteko
            nova_dat.write(vrstica)
            #preberemo naslednjo vrstico
            vrstica = dat.readline()
#zapremo obe datoteki
dat.close()
nova_dat.close()
