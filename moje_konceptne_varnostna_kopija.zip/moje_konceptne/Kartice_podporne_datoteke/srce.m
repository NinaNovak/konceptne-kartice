f = @(x, y) (x.^2 + y.^2 - 1).^3 - x.^2 .* y.^3;
ezplot (f, [-2 2 -2 2])
axis equal