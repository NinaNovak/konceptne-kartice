x=[-10:0.01:10];
plot(x, tan(x), 'r')
ylim([-10 10])