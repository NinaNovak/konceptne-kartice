import os
print("Napiši lokacijo, kjer želiš ustvariti imenik.\n" +\
      "Lokacija naj vključuje ime imenika, na primer:\n" +\
      "C:\\Users\\Nina\\Desktop\\Happy, kjer je Happy neobstoječi imenik.")
pot = input("\nVnesi lokacijo: ")
os.mkdir(pot)  #os.mkdir(pot) je ukaz, s katerim ustvarimo nov imenik (make directory)
print("Imenik je bil ustvarjen.")
