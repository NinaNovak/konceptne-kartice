import os
print("Napiši lokacijo, kjer želiš ustvariti imenik.\n" +\
      "Lokacija naj vključuje ime imenika, na primer:\n" +\
      "C:\\Users\\Nina\\Desktop\\Happy, kjer je Happy neobstoječi imenik.")
pot = input("\nVnesi lokacijo: ")

pot_do, imenik = os.path.split(pot)

#preverimo, ali pot obstaja
if os.path.exists(pot_do):
    #preverimo, ali imenik že obstaja
    if not os.path.isdir(pot):
        os.mkdir(pot)  #os.mkdir(pot) je ukaz, s katerim
                       #ustvarimo nov imenik (make directory)
    else:
        raise Exception("Imenik že obstaja.")
else:
    raise Exception("Pot ni veljavna.")

print("\nImenik je bil ustvarjen.")
