import os
pot = input("Vnesi ime novega imenika: ")
os.mkdir(pot)  #os.mkdir(pot) je ukaz, s katerim ustvarimo nov imenik (make directory)
print("\nImenik " + pot + " je bil ustvarjen v trenutnem delovnem imeniku.")
