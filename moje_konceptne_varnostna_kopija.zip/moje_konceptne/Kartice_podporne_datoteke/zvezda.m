%-------------------------------------------------------------------------------
%oglisca zvezde lahko izracunamo kot tocke na dveh koncentricnih kroznicah s
% polmeroma 3 in 5
%uporabimo parametricno enacbo kroznice
%za sredisce zvezde lahko vzamemo koordinatno izodisce (0, 0)
%-------------------------------------------------------------------------------
oglisca = zeros(32,2);
r1 = 3;  %radij manjse kroznice
r2 = 5;  %radij manjse kroznice
for i = 1:32
  if mod(i,2)==0  %za oglisce izmenicno jemljemo tocke na vecji ali manjsi kr.
    %oglisca zvezde na manjsi kroznici
    x = r1 * cos(i*pi/16);
    oglisca(i, 1) = x;
    y = r1 * sin(i*pi/16);
    oglisca(i, 2) = y;
  else
    %oglisca zvezde na vecji kroznici
    xx = r2 * cos(i*pi/16);
    oglisca(i, 1) = xx;
    yy = r2 * sin(i*pi/16);
    oglisca(i, 2) = yy;
  endif
endfor
fill (oglisca(:,1), oglisca(:,2), "y");
axis equal;
axis([-10 10 -10 10]);