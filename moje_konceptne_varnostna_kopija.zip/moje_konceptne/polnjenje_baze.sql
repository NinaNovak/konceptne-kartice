insert into orodje (ime) values ('Python'), ('C#'), ('Scratch'), ('App Inventor'), ('Octave'), ('Excel'), ('Word'), ('HTML'), ('CSS'), ('SQL'), ('Visual Studio');

insert into konceptna_kartica (naslov, datoteka)
values
('Octave: Graf sinusne funkcije', 'Konceptna_kartica_0001_Octave_Graf_sinusne_funkcije.pdf'),
('Octave: Zvezda', 'Konceptna_kartica_0002_Octave_Zvezda.pdf'),
('Python Turtle: Pentlja', 'Konceptna_kartica_0003_Python_Turtle_Pentlja.pdf'),
('Python Turtle: Risanje po platnu z želvo', 'Konceptna_kartica_0004_Python_Turtle_Risanje_po_platnu_z_zelvo.pdf'),
('Učenje SQL: Mini podatkovna baza', 'Konceptna_kartica_0005_Ucenje_SQL_Mini_podatkovna_baza.pdf');

insert into orodje (ime) values ('Python'), ('C#'), ('Scratch'), ('App Inventor'), ('Octave'), ('Excel'), ('Word'), ('HTML'), ('CSS'), ('SQL'), ('Visual Studio');

insert into kljucna_beseda (beseda) values ('graf'), ('sinus'), ('sin'), ('plot'), ('xlabel'), ('ylabel'), ('title'), ('aqis equal'), ('fill'), ('axis'), ('risanje'), ('turtle'), ('podatkovna baza'), ('tabela'), ('spletna stran'), ('oblikovanje'), ('tan'), ('tangens'), ('ylim'), ('uporabniski vmesnik');

insert into kljucna_beseda (beseda) values ('insert'), ('listen'), ('mainloop');